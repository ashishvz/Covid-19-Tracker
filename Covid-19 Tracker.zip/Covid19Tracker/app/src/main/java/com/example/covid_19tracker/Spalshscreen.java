package com.example.covid_19tracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.widget.ContentLoadingProgressBar;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textview.MaterialTextView;
import com.wang.avi.AVLoadingIndicatorView;

import java.util.List;

public class Spalshscreen extends AppCompatActivity {
    AVLoadingIndicatorView av;
    CountDownTimer timer;
    int conect_count = 0;
    MaterialTextView connect_txt;
    double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spalshscreen);
        av = findViewById(R.id.loading);
        connect_txt = findViewById(R.id.connect_txt);
        timer = new CountDownTimer(3000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                av.show();
            }

            @Override
            public void onFinish() {
                if (conect_count < 3) {
                    if (isNetworkConnected()) {

                            Intent intent = new Intent(Spalshscreen.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                    } else {
                        conect_count++;
                        timer.start();
                    }
                } else {
                    connect_txt.setTextColor(Color.YELLOW);
                    connect_txt.setText(R.string.no_internet);
                    Toast.makeText(getApplicationContext(), R.string.no_internet, Toast.LENGTH_LONG).show();
                }
            }
        };
        timer.start();

    }

    public boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }


}
